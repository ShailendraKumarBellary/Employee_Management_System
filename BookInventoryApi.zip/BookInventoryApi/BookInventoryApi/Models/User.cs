﻿namespace BookInventoryApi.Models
{
    public class User
    {
        public int Id { get; set; }  // Primary Key
        public string Username { get; set; }
        public string Password { get; set; }  // For demo only – store hashed passwords in real apps!
        public string Role { get; set; }      // "Admin" or "User"
    }
}

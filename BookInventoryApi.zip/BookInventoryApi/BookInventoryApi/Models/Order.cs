﻿namespace BookInventoryApi.Models
{
    public class Order
    {
        public int OrderId { get; set; }
        public DateTime OrderDate { get; set; }

        // Foreign Key
        public int CustomerId { get; set; }

        // Navigation
        public Customer Customer { get; set; }
        public ICollection<OrderItem> OrderItems { get; set; }
    }

}

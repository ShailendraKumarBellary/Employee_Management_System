﻿namespace BookInventoryApi.Models
{
    public class OrderItem
    {
        public int OrderItemId { get; set; }

        // Foreign Keys
        public int OrderId { get; set; }
        public int BookId { get; set; }

        public int Quantity { get; set; }

        // Navigation
        public Order? Order { get; set; }
        public Book? Book { get; set; }
    }

}

﻿using BookInventoryApi.Models;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using BookInventoryApi.Models;

namespace BookInventoryApi
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<Book> Books { get; set; }
        public DbSet<Customer> Customers { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<OrderItem> OrderItems { get; set; }
        public DbSet<User> Users { get; set; }
    }

}

﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BookInventoryApi.Models;
using System.Linq;
using System.Threading.Tasks;

namespace BookInventoryApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class OrdersController : ControllerBase
    {
        private readonly AppDbContext _context;

        public OrdersController(AppDbContext context)
        {
            _context = context;
        }

        // POST: api/Orders
        [HttpPost]
        public async Task<ActionResult<Order>> PlaceOrder(OrderRequest orderRequest)
        {
            // Find the customer
            var customer = await _context.Customers.FindAsync(orderRequest.CustomerId);
            if (customer == null)
            {
                return NotFound("Customer not found");
            }

            // Create the order
            var order = new Order
            {
                CustomerId = orderRequest.CustomerId,
                OrderDate = DateTime.Now
            };

            // Add order to database
            _context.Orders.Add(order);
            await _context.SaveChangesAsync();
            foreach (var orderItemRequest in orderRequest.OrderItems)
            {
                var book = await _context.Books.FindAsync(orderItemRequest.BookId);
                if (book == null)
                {
                    return NotFound($"Book with ID {orderItemRequest.BookId} not found");
                }

                if (book.StockQuantity < orderItemRequest.Quantity)
                {
                    return BadRequest($"Not enough stock for {book.Title}");
                }
                book.StockQuantity -= orderItemRequest.Quantity;
                _context.Entry(book).State = EntityState.Modified;
                var orderItem = new OrderItem
                {
                    OrderId = order.OrderId,
                    BookId = orderItemRequest.BookId,
                    Quantity = orderItemRequest.Quantity
                };

                _context.OrderItems.Add(orderItem);
            }

            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetOrder), new { id = order.OrderId }, order);
        }

        // GET: api/Orders/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Order>> GetOrder(int id)
        {
            var order = await _context.Orders
                .Include(o => o.Customer)
                .Include(o => o.OrderItems)
                .ThenInclude(oi => oi.Book)
                .FirstOrDefaultAsync(o => o.OrderId == id);

            if (order == null)
            {
                return NotFound();
            }

            return order;
        }

        // GET: api/Orders/DownloadSummary/5 (Download order summary as CSV/PDF)
        [HttpGet("DownloadOrderSummary/{id}")]
        public async Task<IActionResult> DownloadOrderSummary(int id)
        {
            var order = await _context.Orders
                .Include(o => o.Customer)
                .Include(o => o.OrderItems)
                    .ThenInclude(oi => oi.Book)
                .FirstOrDefaultAsync(o => o.OrderId == id);

            if (order == null)
            {
                return NotFound($"Order with ID {id} not found.");
            }

            var csvContent = GenerateOrderSummaryCsv(order);

            return File(
                System.Text.Encoding.UTF8.GetBytes(csvContent),
                "text/csv",
                $"OrderSummary_{id}.csv"
            );
        }

        private string GenerateOrderSummaryCsv(Order order)
        {
            var headers = new[] { "OrderId", "CustomerName", "BookTitle", "Quantity", "Price", "Total" };
            var csv = string.Join(",", headers) + "\n";

            foreach (var orderItem in order.OrderItems)
            {
                var book = orderItem.Book;
                if (book == null) continue;

                var total = book.Price * orderItem.Quantity;
                csv += $"{order.OrderId},{order.Customer.Name},{book.Title},{orderItem.Quantity},{book.Price},{total}\n";
            }

            return csv;
        }
    }

    // OrderRequest model (for placing orders)
    public class OrderRequest
    {
        public int CustomerId { get; set; }
        public List<OrderItemRequest> OrderItems { get; set; }
    }

    public class OrderItemRequest
    {
        public int BookId { get; set; }
        public int Quantity { get; set; }
    }
}
